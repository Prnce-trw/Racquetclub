@extends('layout.template')

@section('css')
@stop

@section('body')
<div class="panel">
    <div class="panel-heading">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <td>
                            <div class="form-group">
                                <div class="col-md-14">
<a class="btn btn-primary btn-sm" href="{!! url('createteacher') !!}">
                                        <i class="fa fa-group">
                                        </i>
                                        Create Teacher
                                    </a>
                                </div>
                            </div>
                        </td>
                        <div class="panel-title">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered" id="data-table">
                                    <thead>
                                        <tr>
                                            <th>
                                                No.
                                            </th>
                                            <th>
                                                Teacher Name - Surname
                                            </th>
                                            <th>
                                                Nick-Name
                                            </th>
                                            
                                            <th>
                                              Status
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="odd gradeX">
                                            <td>
                                                Trident
                                            </td>
                                            <td>
                                                Internet Explorer 5.0
                                            </td>
                                            <td>
                                                Win 7
                                            </td>
                                           
                                            <td>


                                                <a title="แก้ไข" href="" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i>edit</a>
      
  <form action="" method="post" enctype="multipart/form-data">

                                               {!! csrf_field() !!}
 <input type="hidden"  name="id" value="">
     <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> delete</button>
 </form>
                                            </td>
                                        </tr>
                                       


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </tr>
                </thead>
            </table>
        </div>
        <!-- end panel -->
    </div>
    <!-- end col-12 -->
</div>
<!-- end row -->
<!-- end #content -->
@stop


@section('js')
@stop
