<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register', function () {
    return view('backend.user.register');

});

Route::get('/index', function () {
    return view('backend.user.index');

});

Route::get('/groupsregister', function () {
    return view('backend.user.groupsregister');

});

Route::get('/admin', function () {
    return view('backend.admin.index');

});

Route::get('/create', function () {
    return view('backend.admin.create');

});

Route::get('/permission', function () {
    return view('backend.admin.permission');

});

Route::get('/setpermission', function () {
    return view('backend.admin.setpermission');

});

/// createteacher


Route::get('/index', function () {
    return view('backend.jobrepair.index');

});

Route::get('/worksheet', function () {
    return view('backend.jobrepair.worksheet');

});

Route::get('/manageworksheet', function () {
    return view('backend.jobrepair.manageworksheet');

});

Route::get('/viewworksheet', function () {
    return view('backend.jobrepair.viewworksheet');

});



Route::get('/backend/user', 'userController@user')->name('backoffice');
Route::post('/user/create/', 'userController@create');



/////// การจัดการ แพ็คเกจ  ////
Route::get('/backend/managepackage', 'packageController@managepackage')->name('managepackage');
Route::post('/managepackage/create/', 'packageController@create');
Route::get('/editpackage/{id}', 'packageController@edit');

Route::post('/updatepackage', 'packageController@updatepackage');

Route::post('/delpackage', 'packageController@del');
Route::get('/managepackage/create/','packageController@createform')->name('managepackage.create');

/////// การจัดการ คลาส  ////
Route::get('/backend/manageclass', 'manageclassController@manageclass')->name('manageclass');

Route::post('/manageclass/create/', 'manageclassController@create');

Route::get('/manageclass/create/','manageclassController@createform')->name('manageclass.create');

/////// การจัดการ teacher /////

Route::get('/backend/teacher/', 'teacherController@teacher')->name('teacher');
Route::post('/teacher/create/', 'teacherController@create');

Route::get('/teacher/create/', 'teacherController@teacherform')->name('teacher.create');

