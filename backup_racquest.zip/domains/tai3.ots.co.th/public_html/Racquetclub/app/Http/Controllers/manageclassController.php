<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Manageclass;

use DB;

class manageclassController extends Controller
{
    //public function __construct()
   // {
       // $this->middleware('auth');
  ///  }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function index()
    {

return view('backoffice.dashboard');


    }


public function manageclass()
    {
        $manageclass = Manageclass::all();
        return view('backend.manageclass.index',compact('manageclass'));
        

    }


public function createform()
    {
        
        return view('backend.manageclass.create');
    }



public function create(Request $request)
    {

//dd($request);
        $manageclass = new Manageclass();
        $manageclass->classID = $request->classID;
        $manageclass->class_title  = $request->class_title;
        $manageclass->hour  = $request->hour;
        $manageclass->price  = $request->price;
        $manageclass->price_hour  = $request->price_hour;
      $manageclass->Status  = '1';
        $manageclass->save();
        return redirect()->to('backend/manageclass/')->with('success', 'success');
    }

}