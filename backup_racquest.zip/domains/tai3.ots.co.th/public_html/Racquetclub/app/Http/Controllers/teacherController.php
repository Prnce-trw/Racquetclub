<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;



use App\Teacher;

use DB;


class teacherController extends Controller
{
   // public function __construct()
    //{
     //   $this->middleware('auth');
    //}

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function index()
    {

return view('backoffice.dashboard');


    }


     public function teacher()
    {

        $teacher = Teacher::all();
           return view('backend.teacher.index',compact('teacher'));
  
    }

public function teacherform()
    {
        
        return view('backend.teacher.create');
    }

    public function create(Request $request)
    {

//dd($request);
        $teacher = new Teacher();
        $teacher->Teachername = $request->Teachername;
        $teacher->surename = $request->surename;
       $teacher->nickname  = $request->nickname;
       $teacher->Status  = '1';

        $teacher->save();
        return redirect()->to('backend/teacher')->with('success', 'success');
    }

}