<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Member;

use DB;

class userController extends Controller
{
    /*public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {

        return view('backoffice.dashboard');

    }



public function user()
    {
        $member = Member::all();

        return view('backend.user.index',compact('member'));
        

    }





    public function create(Request $request)
    {

//dd($request);
        $member = new Member();

        $member->registerdate = $request->registerdate;
        $member->membergroup  = $request->membergroup;

        $member->name  = $request->name;
        $member->surname  = $request->surname;
        $member->startdate  = $request->startdate;

         $member->enddate  = $request->enddate;
        $member->tel  = $request->tel;
        $member->email  = $request->email;

         $member->birthday  = $request->birthday;
        $member->gender  = $request->gender;
        $member->groups  = $request->groups;

        $member->package  = $request->package;
        $member->address  = $request->address;
        $member->country  = $request->country;
        $member->website  = $request->website;
        $member->sport  = $request->sport;


        //if ($request->file('memberFile_1')) {
           // $filename = time() .'.' . $request->file('memberFile_1')->getClientOriginalExtension();
          
           // $request->file('memberFile_1')->move(storage_path().'\memberFile_1',$filename);

            //dd($request);


          //  $member->image = $filename;
        //} 

        $member->save();
        return redirect()->to('backend/user')->with('success', 'success');
    }
    

}
