<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    protected $table = 'member';

protected $fillable = ['registerdate','membergroup','name','name','surname','startdate','enddate','tel','email','birthday','gender','groups','package','address','country','website','sport'];
}
